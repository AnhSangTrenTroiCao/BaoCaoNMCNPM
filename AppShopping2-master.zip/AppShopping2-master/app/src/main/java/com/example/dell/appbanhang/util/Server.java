package com.example.dell.appbanhang.util;

public class Server {
    public static String localhost = "192.168.1.125";
    public static String Duongdanloaisp = "http://" + localhost + "/server/getloaisp.php";
    public static String Duongdanspmoinhat = "http://" + localhost + "/server/getsanphammoinhat.php";
    public static String Duongdandienthoai = "http://" + localhost + "/server/getidsanpham.php?page=";
    public static String Duongdanthongtinkhachahng = "http://" + localhost + "/server/thongtinkhachhang.php";
    public static String Duongdanchitietdonhang = "http://" + localhost + "/server/chitietdonhang.php";
}
